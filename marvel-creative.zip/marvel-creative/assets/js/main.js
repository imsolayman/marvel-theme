(function ($) {
    "use strict";

    $(document).ready(function ($) {


        $(".embed-responsive iframe").addClass("embed-responsive-item");
        $(".carousel-inner .item:first-child").addClass("active");

        $('[data-toggle="tooltip"]').tooltip();


        /*---------------------------------------------------
                    Isotop menu
        ---------------------------------------------------*/
        

        /*---------------------------------------------------
                    Lightbox
        ---------------------------------------------------*/

        $(".gallery-lightbox").magnificPopup({
            type: 'image',
            gallery: {
                enabled: true
            }
        });


        /*---------------------------------------------------
                    Smooth menu
        ---------------------------------------------------*/

        $('li.smooth-menu a').on('click', function () {
            var headerH = "70";
            $('html, body').animate({
                scrollTop: $($(this).attr('href')).offset().top - headerH + 'px'
            }, 1208, 'easeInOutExpo');

        });

        /*---------------------------------------------------
                          Counter
        ---------------------------------------------------*/

        $('.counter').counterUp({
            delay: 10,
            time: 1000
        });
        /*---------------------------------------------------
                          Nav menu
        ---------------------------------------------------*/

        $(function () {
            $('#navmenu').slicknav();
        });

        /*---------------------------------------------------
                    Sticky menu
        ---------------------------------------------------*/

        $("#menu-area").sticky({
            topSpacing: 0
        });

        /*---------------------------------------------------
                   WOW
        ---------------------------------------------------*/
        new WOW().init();



    });

    $(window).load(function () {

    });

}(jQuery));