<?php
get_template_part('/inc/marvel-framework/cs-framework');

// framework Metabox options filter example
function marvel_cs_metabox_options($options)
{

    $options = array(); // remove old options
    //All page option meta
    $options[] = array(
        'id' => 'theme_page_meta',
        'title' => 'Page Options',
        'post_type' => 'page',
        'context' => 'normal',
        'priority' => 'default',
        'sections' => array(
            array(
                'name' => 'theme_page_metabox',
                'title' => 'Page Options',
                'fields' => array(
                    // begin: a field
                    array(
                        'id' => 'enable_title',
                        'type' => 'switcher',
                        'title' => 'Enable Page Breadcrumb',
                        'default' => 'false'
                    ) ,
                    // end: a field
                    
                )
            )
        )
    );

    return $options;

}
add_filter('cs_metabox_options', 'marvel_cs_metabox_options');

// framework Theme options filter example
function marvel_theme_options($options)
{

    $options = array();

     $options[] = array(
        'name' => 'header_options',
        'title' => 'Header Options',
        'icon' => 'fa fa-minus',
        'sections' => array(

            //Header top left start
            array(
                'name' => 'header_option',
                'title' => 'Headet Top Option',
                'icon' => 'fa fa-minus',
                'fields' => array(

                    array(
                        'id' => 'header_option_field',
                        'type' => 'fieldset',
                        'title' => 'Stacky Menu',
                        'un_array' => true,
                        'fields' => array(
                            array(
                                'id' => 'stacky_menu',                                
                                'type' => 'switcher',                                
                                'default' => 'false'
                            ) ,
                            
                        )
                    ) ,                      

                )
            ) ,
            //End left section
            
        )
    );
    
    //Blog Option Start
    $options[] = array(
        'name' => 'marvel_blog_options',
        'title' => 'Blog Options',
        'icon' => 'fa fa-heart',
        'fields' => array(
            array(
                'id' => 'enable_post_by',
                'type' => 'switcher',
                'title' => 'Display Posted By',
                'default' => true
            ),
            array(
                'id' => 'enable_posted_on',
                'type' => 'switcher',
                'title' => 'Display Posted On',
                'default' => true
            ),
            array(
                'id' => 'enable_post_category',
                'type' => 'switcher',
                'title' => 'Display Posted category',
                'default' => true
            ), 
            array(
                'id' => 'enable_post_tag',
                'type' => 'switcher',
                'title' => 'Display Posted Tag',
                'default' => true
            ),
            array(
                'id' => 'enable_comment_option',
                'type' => 'switcher',
                'title' => 'Display Comment Option',
                'default' => true
            ),
            array(
                'id' => 'enable_single_post_pagination',
                'type' => 'switcher',
                'title' => 'Display Single Post Pagination',
                'default' => true
            ),
        )
        
    );
//Blog Option End
    
    //Add acording option
    $options[] = array(
        'name' => 'footer_options',
        'title' => 'Footer Options',
        'icon' => 'fa fa-minus',
        'sections' => array(

            //Header top left start
            array(
                'name' => 'footer_top_options',
                'title' => 'Footer Top',
                'icon' => 'fa fa-minus',
                'fields' => array(

                    array(
                        'id' => 'footer_one',
                        'type' => 'fieldset',
                        'title' => 'Footer Widget One',
                        'un_array' => true,
                        'fields' => array(
                            array(
                                'id' => 'company_phone_number',
                                'type' => 'text',
                                'title' => 'Company Phone Number',
                                'default' => 'Phone : (999) 000-122-233'
                            ) ,
                            array(
                                'id' => 'company_phone_icon',
                                'type' => 'icon',
                                'title' => 'Phone Icon',
                                'default' => 'fa fa-tablet',
                            ) ,
                        )
                    ) ,

                    array(
                        'id' => 'footer_two',
                        'type' => 'fieldset',
                        'title' => 'Footer Widget Two',
                        'un_array' => true,
                        'fields' => array(
                            array(
                                'id' => 'footer_top_social',
                                'type' => 'group',
                                'title' => 'Footer Social Information',
                                'button_title' => 'Add New Social Info',
                                'accordion_title' => 'Add detail social information',
                                'fields' => array(

                                    array(
                                        'id' => 'footer_top_social_icon',
                                        'type' => 'icon',
                                        'title' => 'add social icon',
                                        'default' => 'fa fa-heart'
                                    ) ,

                                    array(
                                        'id' => 'footer_social_top_link',
                                        'type' => 'text',
                                        'title' => 'Enter your social link',
                                        'default' => 'https://facebook.com'
                                    )

                                )
                            )

                        )
                    ) ,

                       array(
                        'id' => 'footer_three',
                        'type' => 'fieldset',
                        'title' => 'Footer Widget three',
                        'un_array' => true,
                        'fields' => array(
                            array(
                                'id' => 'company_address',
                                'type' => 'text',
                                'title' => 'Company Location',
                                'default' => '123 state, South America, 205'
                            ) ,
                            array(
                                'id' => 'company_location_icon',
                                'type' => 'icon',
                                'title' => 'Phone Icon',
                                'default' => 'fa fa-globe',
                            ) ,
                        )
                    ) ,

                )
            ) ,
            //End left section
            array(
                'name' => 'footer_bottom_options',
                'title' => 'Footer Bottom',
                'icon' => 'fa fa-minus',
                'fields' => array(

                    array(
                        'id' => 'footer_bottom_left',
                        'type' => 'fieldset',
                        'title' => 'Footer Bottom Left Section',
                        'un_array' => true,
                        'fields' => array(

                            array(
                                'id' => 'footer_copyright_text',
                                'type' => 'text',
                                'title' => 'Copyright Text',
                                'default' => 'Copyright © 2016 - Template Powered By'
                            ) ,

                        )
                    ) ,

                )
            )
        )
    );

    $options[] = array(
        'name' => 'script_section',
        'title' => 'Script Section',
        'fields' => array(
            array(
                'id' => 'custom_css',
                'type' => 'textarea',
                'sanitize' => false,
                'title' => 'Custom Css'
            )
        )
    );

    return $options;

}
add_filter('cs_framework_options', 'marvel_theme_options');

// framework Customize options filter example
function marvel_custom_framework_options($options)
{

    $options = array(); // remove old options
    return $options;

}
add_filter('cs_customize_options', 'marvel_custom_framework_options');

