    <!--Viewport area start-->
    <div id="home" class="viewport-area">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="viewport-content wow bounceInLeft">
                        <h1>CREATIVE <br> AND PROFESSIONAL </h1>
                        <p>Use, by you or one client, in a single end product which end users are not charged for. Use, by you or one client, in a single end product which end users are not charged for.</p>
                        <li class="smooth-menu"><a href="#contact">Contact Us</a></li>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Viewport area End-->

    <!--menu area start-->
    <div class="menu-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="logo">
                        <a href=""><img src="assets/images/logo.png" alt="image"></a>
                    </div>
                    <ul class="main-menu" id="navmenu">
                        <li class="smooth-menu"><a href="#home">HOME</a></li>
                        <li class="smooth-menu"><a href="#service">SERVICE</a></li>
                        <li class="smooth-menu"><a href="#about">ABOUT</a></li>
                        <li class="smooth-menu"><a href="#portfolio">PROTFOLIO</a></li>
                        <li class="smooth-menu"><a href="#blog">BLOG</a></li>
                        <li class="smooth-menu"><a href="#">PAGE</a></li>
                        <li class="smooth-menu"><a href="#contact">CONTACT</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!--menu area End-->